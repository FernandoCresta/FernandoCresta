package ar.org.fp.curso.java.entities;

import java.text.DecimalFormat;

public class Moto extends Vehiculo {
    private int cilindrada;

    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;

    }

    @Override
    public String toString() {
        /*
         * seguimos el formato tal cual como esta especifcado para hacer el toString
         * Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00
         */
        DecimalFormat df = new DecimalFormat("###,##0.00");
        return "Marca: " + this.getMarca() + "// Modelo: " + this.getModelo() +
                " // Cilindrada: " + this.getCilindrada() + "c // Precio: $" + df.format(this.getPrecio());
    }

    public int getCilindrada() {
        return cilindrada;
    }
}
