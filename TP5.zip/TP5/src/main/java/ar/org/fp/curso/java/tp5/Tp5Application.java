package ar.org.fp.curso.java.tp5;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp5Application {

	public static void main(String[] args) {
		//SpringApplication.run(Tp4Application.class, args);
		Tp5.main(args);
	}

}