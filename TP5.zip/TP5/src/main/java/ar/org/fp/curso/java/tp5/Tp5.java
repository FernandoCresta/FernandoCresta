package ar.org.fp.curso.java.tp5;

import ar.org.fp.curso.java.entities.Auto;
import ar.org.fp.curso.java.entities.Moto;
import ar.org.fp.curso.java.entities.Vehiculo;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Tp5 {

    private static List<Vehiculo> vehiculos = new ArrayList();

    public static void main(String[] args) {
        cargarLista();
        System.out.println(" ");
        mostrarLista();
        separarConIguales();
        mostrarMascaro();
        mostrarMasbarato();
        mostrarCony();
        separarConIguales();
        ordenarPorPrecio();
        separarConIguales();
        ordenarNatural();
        separarConIguales();
    }

    private static void cargarLista() {
        vehiculos.add(new Auto("Peugeot", "206", 200000, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000, 125));
        vehiculos.add(new Auto("Peugeot", "208", 250000, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.5, 160));
    }

    private static void mostrarLista() {
        vehiculos.forEach(System.out::println);
    }

    private static void separarConIguales() {
        System.out.println("");
        System.out.println("=".repeat(28));
        System.out.println("");
    }

    private static void mostrarMascaro() {
        Vehiculo vehiculoCaro = vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println("Vehiculo más caro: " + vehiculoCaro.getMarca() + " " +
                vehiculoCaro.getModelo());
    }

    private static void mostrarMasbarato() {
        Vehiculo vehiculoBar = vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println("Vehiculo más barato: " + vehiculoBar.getMarca() + " " +
                vehiculoBar.getModelo());
    }

    private static void mostrarCony() {
        DecimalFormat df = new DecimalFormat("###,##0.00");
        vehiculos
                .stream()
                .filter(o -> o.getModelo().toUpperCase().contains("Y"))
                .forEach(o -> System.out.println(
                        "Vehículo que contiene en el modelo la letra 'Y': " +
                                o.getMarca() + " " +
                                o.getModelo() + " $" +
                                df.format(o.getPrecio())));
    }

    private static void ordenarPorPrecio() {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(o -> System.out.println(o.getMarca() + " " + o.getModelo()));
    }

    /* Usamos el orden natural establecido en el compareTo de la 
       clase Vehiculo
     */
    private static void ordenarNatural() {
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }
}
