package ar.org.fp.curso.java.entities;

import java.text.DecimalFormat;
/* No se implentan metodos con Lombok ya que es necesario desarrollar
 * codigo con funciones nativas JDK8. Lombok no cae en ese criterio
 */
 import java.text.DecimalFormatSymbols;

public abstract class Vehiculo implements Comparable <Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca= marca;
        this.modelo= modelo;
        this.precio= precio;
    }
    /*
     * Se implementa un compareTo para Vehiculo para el sort del
     * Api Stream -metodo sort-Y para evitar que un nro que aparenta ser menor sea en realidad mayor 
     * agregando 0 delante soluciono este problema
     */
     // marca, modelo y precio
     @Override
    public int compareTo(Vehiculo para) {
        DecimalFormat df = new DecimalFormat("000,000.00");
        String thisVehiculo = this.getMarca()+","+this.getModelo()+","+df.format(this.getPrecio());
        String paraVehiculo = para.getMarca()+","+para.getModelo()+","+df.format(para.getPrecio());
        return thisVehiculo.compareTo(paraVehiculo);
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

}
