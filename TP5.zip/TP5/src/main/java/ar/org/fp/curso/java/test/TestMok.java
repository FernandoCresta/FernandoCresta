package ar.org.fp.curso.java.test;

/*
Probamos la generación de objetos experimentales de la Clase Auto y Moto, la impresión de los mismos-
TpString
*/

import ar.org.fp.curso.java.entities.Auto;
import ar.org.fp.curso.java.entities.Moto;

public class TestMok {
    public static void main(String[] args) {
        //Test de Objetos Mocks (Objetos Simulados)
        System.out.println();
        System.out.println("-- Auto --");
        Auto auto1= new Auto( "VW", "Polo",400000.2, 4);
        System.out.println(auto1);
        System.out.println();
        System.out.println("-- Moto --");
        Moto moto1= new Moto("Kawasaki","400", 78000, 400);
        System.out.println(moto1);
        System.out.println();

    }
}
