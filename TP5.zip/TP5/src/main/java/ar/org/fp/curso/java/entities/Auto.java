package ar.org.fp.curso.java.entities;

import java.text.DecimalFormat;

public class Auto extends Vehiculo {
    private int puertas;

    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        /*
         * seguimos el formato tal cual como esta especifcado para hacer el toString
         * Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00
         */
        DecimalFormat df = new DecimalFormat("###,##0.00");
        return "Marca: " + this.getMarca() + " // Modelo: " + this.getModelo() +
                " // Puertas: " + this.getPuertas() + " // Precio: $" + df.format(this.getPrecio());
    }

    public int getPuertas() {
        return puertas;
    }
}
