package ar.org.fp.curso.java;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ar.org.fp.curso.java.tp4.Tp4;



@SpringBootApplication
public class Tp4Application {

	public static void main(String[] args) {
		//SpringApplication.run(Tp4Application.class, args);
		Tp4.main(args);
	}

}
