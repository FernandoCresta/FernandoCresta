package ar.org.fp.curso.java.entities;

import lombok.Getter;

/*
 * Se intentó manejar todas los métodos posibles y comunes en esta clase
 * con su propia implementación. Se sobrecargaron constructores para Auto
 * Clasico
 * y Auto Nuevo
 * No se dejó librada al azar la generación del objeto radio los cambios y
 * asignaciones
 * los realiza Vehiculo, ya que corremos con el posible error de asignar una
 * misma
 * radio a 2 Vehiculos distintos
 */

@Getter
public abstract class Vehiculo {

    private String color;
    private String marca;
    private String modelo;
    private double precio;
    private Radio radio;
    

    // Creación del objeto para AutoClasico
    /**
     * @param color  parametro de color
     * @param marca  parametro de marca
     * @param modelo parametro de modelo
     */
    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    // Creación del objeto para AutoNuevo
    /**
     * @param color    parametro de color
     * @param marca    parametro de marca
     * @param modelo   parametro de modelo
     * @param marcaRadio   parametro de la marca de la radio
     * @param potencia parametro de potencia de la radio
     */

    public Vehiculo(String color, String marca, String modelo, String marcaRadio, float potencia) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.radio = new Radio(marcaRadio, potencia);
        
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    // Agregar la radio al vehículo
    public void agregarRadio(String marcaRadio, float potencia) {
        if (this.radio == null) {
            this.radio = new Radio(marcaRadio, potencia);
            
        } else {
            System.out.println("Este Vehiculo ya tiene una radio.");
        }
    }

    // Cambiar la radio al vehículo
    public void cambiarRadio(String marcaRadio, float potencia) {
        if (this.radio != null) {
            this.radio = new Radio(marcaRadio, potencia);
            
        } else {
            System.out.println("Este Vehiculo no tiene radio para cambiar");
        }
    }

    /**
     * Aqui heradaremos el toString para las clases hijas donde se le agregara
     * el nombre del Auto Nuevo, Clasico o Bondi
     */
    @Override
    public String toString() {
        return "color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio
                + ", radio=" + radio ;
    }

}
