package ar.org.fp.curso.java.tp4;

public class Tp4 {
    public static void main(String[] args) {
        System.out.println("");
        System.out.println("Programa principal");
        System.out.println("");
    }
}
