package ar.org.fp.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
/**
 * Suponbemos que la potencia de la radio es en watts y 
 * para darle mas precision le ponemos float
 */
@Data
@AllArgsConstructor

public class Radio {
   private String marcaRadio;
   private float potencia;  
}
