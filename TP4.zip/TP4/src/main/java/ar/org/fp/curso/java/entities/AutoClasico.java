package ar.org.fp.curso.java.entities;

public class AutoClasico extends Vehiculo {

    /**
     * @param color  viene de la clase padre Vehiculo
     * @param marca  viene de la clase padre Vehiculo
     * @param modelo viene de la clase padre Vehiculo
     */
    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }    
    
    @Override
    public String toString() {
        return "AutoClasico(" + super.toString() + ")";
    }
}
