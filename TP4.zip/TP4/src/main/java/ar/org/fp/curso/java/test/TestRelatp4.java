package ar.org.fp.curso.java.test;

import ar.org.fp.curso.java.entities.AutoClasico;
import ar.org.fp.curso.java.entities.AutoNuevo;
import ar.org.fp.curso.java.entities.Bondi;
import ar.org.fp.curso.java.entities.Radio;

import lombok.ToString;

/**
 * Todos los Vehiculos, como AutoClasico, AutoNuevo, Bondi tienen los mismos atributos
 * y la unia diferencia encontras es que el AutoNuevo si si viene con Radio, por lo
 * que varía sólo el constructor - utilizando el super de Vehículo-.
 * La cambiabilidad de la Radio es para todos igual, por ello el método se coloca en 
 * Vehiculo.
 * Importante: la forma que tenemos para ver si tiene radio es preguntando por null-
 * en el objeto radio que pertenece a vehiculo. Debe haber mejores implementaciones
 * por lo que si el campo es null no podemos cambiar de Radio. - Debe haber mejores 
 * implementaciones.
 * Definimos un ToString para Vehiculo sin el nombre de esta clase, luego lo heredamos 
 * y agregamos el nombre de la clase concatenada con los atributos de Vehiculo.
 * 
 */
@ToString
public class TestRelatp4 {
    public static void main(String[] args) {
        //Test de Objetos Mocks (Objetos Simulados)
        System.out.println();
        System.out.println("-- Radio --");
        Radio radio1 =new Radio("Phillips",(float) 14.50);
        System.out.println(radio1);
        System.out.println();
        /* 
        System.out.println("-- Vehiculo --");
        Vehiculo vehiculo1 = new Vehiculo("rojo", "Fiat", "Palio"); 
         Muestra:     Cannot instantiate the type Vehiculo
        */
        System.out.println("-- AutoClasico  sin radio--");
        AutoClasico autoClasico = new AutoClasico ("rojo", "Fiat", "Palio");
        System.out.println(autoClasico);
        System.out.println();

        System.out.println("-- Cambio Radio a AutoClasico sin radio--");
        autoClasico.cambiarRadio("Sony", (float) 55.5);
        System.out.println(autoClasico);
        System.out.println();

        System.out.println("-- Asignacion Radio a AutoClasico --");
        autoClasico.agregarRadio("Pioneer", (float) 50.2);
        System.out.println(autoClasico);
        System.out.println();

        System.out.println("-- Asignacion de otra Radio al mismo AutoClasico --");
        autoClasico.agregarRadio("Sansei", (float) 50.2);
        System.out.println(autoClasico);
        System.out.println();

        System.out.println("-- Cambio Radio a AutoClasico --");
        autoClasico.cambiarRadio("Samsung", (float) 45.5);
        System.out.println(autoClasico);
        System.out.println();

        System.out.println("-- AutoNuevo con radio--");
        AutoNuevo autoNuevo = new AutoNuevo ("azul", "Chevrolet", "Serie 2","Philco", (float)20.5);
        System.out.println(autoNuevo);
        System.out.println();

        System.out.println("-- Cambio Radio a AutoNuevo --");
        autoNuevo.cambiarRadio("Aiwa", (float) 25.4);
        System.out.println(autoNuevo);
        System.out.println();

        System.out.println("-- Bondi sin radio--");
        Bondi bondi = new Bondi ("verde", "Mercedez Benz", "T34");
        System.out.println(bondi);
        System.out.println();

        System.out.println("-- Cambio Radio a Bondi sin radio --");
        bondi.cambiarRadio("Kenia", (float) 32.5);
        System.out.println(bondi);
        System.out.println();
       

        System.out.println("-- Agrego precio a un Vehiculo Bondi --");
        bondi.setPrecio(100000.50);
        System.out.println(bondi);
        System.out.println();

    }
}
