package ar.org.fp.curso.java.entities;

final public class Bondi extends Vehiculo {

    /**
     * @param color  viene de la clase padre Vehiculo
     * @param marca  viene de la clase padre Vehiculo
     * @param modelo viene de la clase padre Vehiculo
     */
    public Bondi(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    @Override
    public String toString() {
        return "Bondi(" + super.toString() + ")";
    }
}
