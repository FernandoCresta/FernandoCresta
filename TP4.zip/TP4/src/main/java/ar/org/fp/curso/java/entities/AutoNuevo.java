package ar.org.fp.curso.java.entities;

public class AutoNuevo extends Vehiculo {

    /**
     * @param color  viene de la clase padre Vehiculo
     * @param marca  viene de la clase padre Vehiculo
     * @param modelo viene de la clase padre Vehiculo
     */
    public AutoNuevo(String color, String marca, String modelo, String marcaRadio,
            float potencia) {
        super(color, marca, modelo, marcaRadio, potencia);
    }

    @Override
    public String toString() {
        return "AutoNuevo(" + super.toString() + ")";
    }
}
