
function calcularMasaCorporal(){
    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value)
    campoimc= document.getElementById("imc")
    if ((peso<= 0) || (altura <= 0)){
        campoimc.setAttribute("value","Error, ningún dato debe ser 0 !")
    }
    else{
        altura=altura/100
        imc= peso /(altura * altura)
        // fijamos a 1 decimal y mostramos la cadena
        campoimc.setAttribute("value",imc.toFixed(1))
    }
    obtenerEstado(imc)
}

function obtenerEstado(imc) {
    estado =""
    campoestado= document.getElementById("estado")
    campoestado.classList.remove("text-secondary");
    color= "text-secondary"
    /* con el imc calculamos el estado correspondiente y modificamos 
    los colores del texto si la vida del individuo corre riesgos*/

    if (imc < 15) {
        estado = "DELGADEZ MUY SEVERA"
        color= "text-danger"
    } 
    else if (imc >= 15 && imc <= 15.9) {
        estado = "DELGADEZ SEVERA"
        color= "text-danger"
    } 
    else if (imc > 15.9 && imc <= 18.4) {
        estado = "DELGADEZ";
    } 
    else if (imc > 18.4 && imc <= 24.9) {
        estado = "PESO NORMAL";
    }   
     else if (imc > 24.9 && imc <= 29.9) {
        estado = "SOBREPESO";
    }
    else if (imc > 29.9 && imc <= 34.9) {
        estado = "OBESIDAD";
        color= "text-danger"
    } 
    else if (imc >= 35 && imc <= 39.9) {
        estado = "OBESIDAD SEVERA";
        color= "text-danger"
    }
     else if (imc > 39.9) {
        estado = "OBESIDAD MORBIDA";
        color= "text-danger"
    } 
    /* manejamos la clase de los colores según el estado del ICM con Javascript*/
    campoestado.className = "p-2 form-control-plaintext " + color+  " bg-success-subtle" ;
    campoestado.setAttribute("value",estado)
}

// reseteamos y borramos tambien los campos de IMC y estado. El standard reset no queda muy lindo"
function resetear(){
    document.getElementById("peso").value="0" // funciona para int y no para text
    document.getElementById("altura").value= "0"
    document.getElementById("imc").setAttribute("value",0) // funciona para text pero no para int
    document.getElementById("estado").setAttribute("value","")
}